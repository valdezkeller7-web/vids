import os, tempfile, unittest, sqlite3
from datetime import date
from app import create_app, init_demo_db

HOY = date(2026, 11, 21)


class BaseTest(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db"); os.close(fd)
        self.app = create_app({"SQLITE_PATH": self.path, "TESTING": True}, hoy=HOY)
        init_demo_db(self.app)
        self.db = self.app.extensions["db"]
        self.svc = self.app.extensions["servicios"]
        self.client = self.app.test_client()

    def tearDown(self):
        os.remove(self.path)
