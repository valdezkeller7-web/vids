import sqlite3
from tests.base import BaseTest
from app.dao import CategoriaDAO, ProductoDAO, ServicioDAO, ContactoDAO, PromocionDAO
from app.models import Contacto


class TestDAO(BaseTest):
    def test_dao01_listar_categorias(self):
        self.assertEqual(len(CategoriaDAO(self.db).listar()), 5)

    def test_dao02_productos_por_categoria(self):
        prods = ProductoDAO(self.db).listar_por_categoria(1)
        self.assertEqual(len(prods), 3)
        self.assertTrue(all(p.id_categoria == 1 for p in prods))

    def test_dao03_obtener_inexistente_devuelve_none(self):
        self.assertIsNone(CategoriaDAO(self.db).obtener(999))
        self.assertIsNone(ProductoDAO(self.db).obtener(999))

    def test_dao04_fk_restrict_categoria_con_productos(self):
        with self.assertRaises(sqlite3.IntegrityError):
            CategoriaDAO(self.db).eliminar(1)

    def test_dao05_check_fechas_promocion(self):
        with self.assertRaises(sqlite3.IntegrityError):
            PromocionDAO(self.db).crear("Inválida", "x", "2026-12-31", "2026-12-01")

    def test_dao06_unique_servicio(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO servicio (nombre) VALUES (?)", ("Atención farmacéutica",))

    def test_dao07_set_null_al_eliminar_servicio(self):
        cid = ContactoDAO(self.db).guardar(Contacto("Ana", "ana@correo.com", "Consulta de prueba", 1))
        ServicioDAO(self.db).eliminar(1)
        self.assertIsNone(ContactoDAO(self.db).obtener(cid)["id_servicio"])

    def test_dao08_cascade_promocion_producto(self):
        self.db.execute("DELETE FROM promocion WHERE id_promocion = 1")
        n = self.db.query("SELECT COUNT(*) AS n FROM promocion_producto WHERE id_promocion = 1")[0]["n"]
        self.assertEqual(n, 0)
