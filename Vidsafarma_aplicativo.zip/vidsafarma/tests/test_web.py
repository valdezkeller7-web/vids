from tests.base import BaseTest


class TestWeb(BaseTest):
    RUTAS = ["/", "/categorias", "/categorias/1", "/productos/1", "/promociones",
             "/servicios", "/salud", "/salud/1", "/contacto"]

    def test_web01_rutas_principales_responden_200(self):
        for r in self.RUTAS:
            with self.subTest(ruta=r):
                self.assertEqual(self.client.get(r).status_code, 200)

    def test_web02_categoria_inexistente_404_amigable(self):
        r = self.client.get("/categorias/999")
        self.assertEqual(r.status_code, 404); self.assertIn("Contenido no disponible", r.get_data(as_text=True))

    def test_web03_promociones_no_muestra_vencidas(self):
        html = self.client.get("/promociones").get_data(as_text=True)
        self.assertIn("Semana del cuidado personal", html); self.assertNotIn("finalizada", html)

    def test_web04_formulario_invalido_400_con_mensajes(self):
        r = self.client.post("/contacto", data={"nombre": "", "medio_contacto": "x", "mensaje": ""})
        t = r.get_data(as_text=True)
        self.assertEqual(r.status_code, 400); self.assertIn("Ingrese su nombre.", t)

    def test_web05_formulario_valido_guarda_y_confirma(self):
        r = self.client.post("/contacto", data={"nombre": "Ana", "medio_contacto": "ana@correo.com",
                             "mensaje": "¿Cuál es el horario de atención?", "id_servicio": "2"}, follow_redirects=True)
        self.assertEqual(r.status_code, 200); self.assertIn("Recibimos su consulta", r.get_data(as_text=True))
        self.assertEqual(self.db.query("SELECT COUNT(*) AS n FROM contacto")[0]["n"], 1)

    def test_web06_contacto_sin_datos_confirmados_muestra_aviso(self):
        self.assertIn("se publicarán cuando sean confirmados", self.client.get("/contacto").get_data(as_text=True))

    def test_web07_sin_funciones_transaccionales(self):
        for r in ["/carrito", "/pedidos", "/pago", "/login"]:
            self.assertEqual(self.client.get(r).status_code, 404)
