from tests.base import BaseTest


class TestServicios(BaseTest):
    def test_srv01_promociones_vigentes_excluye_vencidas(self):
        titulos = [p.titulo for p, _ in self.svc["promociones"].vigentes()]
        self.assertEqual(len(titulos), 2)
        self.assertFalse(any("finalizada" in t for t in titulos))

    def test_srv02_categoria_inexistente(self):
        self.assertIsNone(self.svc["catalogo"].productos_de_categoria(999))

    def test_srv03_categoria_valida_con_productos(self):
        cat, prods = self.svc["catalogo"].productos_de_categoria(4)
        self.assertEqual(cat.nombre, "Botiquín y primeros auxilios"); self.assertEqual(len(prods), 3)

    def test_srv04_contacto_campos_obligatorios(self):
        _, err = self.svc["contacto"].enviar("", "", "")
        self.assertEqual(set(err), {"nombre", "medio_contacto", "mensaje"})

    def test_srv05_contacto_medio_invalido(self):
        _, err = self.svc["contacto"].enviar("Ana", "no-es-correo", "Mensaje suficientemente largo")
        self.assertIn("medio_contacto", err)

    def test_srv06_contacto_mensaje_corto(self):
        _, err = self.svc["contacto"].enviar("Ana", "ana@correo.com", "hola")
        self.assertIn("mensaje", err)

    def test_srv07_contacto_valido_se_registra(self):
        cid, err = self.svc["contacto"].enviar("Ana", "ana@correo.com", "¿Tienen horario de atención?", 2)
        self.assertEqual(err, {}); self.assertIsNotNone(cid)

    def test_srv08_datos_no_confirmados_no_se_publican(self):
        self.assertEqual(self.svc["contacto"].datos_publicados(), {})
