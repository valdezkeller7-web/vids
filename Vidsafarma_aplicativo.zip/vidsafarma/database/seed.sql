-- DATOS DE DEMOSTRACIÓN: deben reemplazarse por el catálogo validado por Vidsafarma.
INSERT INTO categoria (nombre, descripcion) VALUES
 ('Cuidado personal','Productos de higiene y cuidado diario.'),
 ('Vitaminas y suplementos','Suplementos nutricionales de uso general.'),
 ('Bebés y maternidad','Artículos de cuidado para bebés y mamás.'),
 ('Botiquín y primeros auxilios','Insumos básicos para el botiquín del hogar.'),
 ('Bienestar','Artículos de bienestar y cuidado del hogar.');
INSERT INTO producto (id_categoria,nombre,descripcion,presentacion,imagen_url,destacado) VALUES
 (1,'Jabón líquido antibacterial','Jabón líquido para higiene de manos de uso diario.','Frasco 250 ml',NULL,1),
 (1,'Crema hidratante corporal','Crema de uso diario para el cuidado de la piel seca.','Pote 400 g',NULL,0),
 (1,'Protector solar facial','Protector solar de uso diario para el rostro.','Tubo 50 ml',NULL,1),
 (2,'Vitamina C masticable','Suplemento de vitamina C en tabletas masticables.','Caja x 30 tabletas',NULL,0),
 (2,'Multivitamínico diario','Suplemento multivitamínico de uso general.','Frasco x 60 cápsulas',NULL,1),
 (3,'Pañitos húmedos sin fragancia','Pañitos húmedos suaves para el cuidado del bebé.','Paquete x 80 unidades',NULL,0),
 (3,'Crema para pañal','Crema protectora para la zona del pañal.','Tubo 100 g',NULL,0),
 (4,'Alcohol en gel','Alcohol en gel para desinfección de manos.','Frasco 500 ml',NULL,1),
 (4,'Gasas estériles','Gasas estériles para curaciones simples.','Sobre x 10 unidades',NULL,0),
 (4,'Termómetro digital','Termómetro digital de uso doméstico.','Unidad',NULL,0),
 (5,'Humidificador de ambiente','Humidificador compacto para el hogar.','Unidad',NULL,0),
 (5,'Pastillero semanal','Organizador semanal para pastillas.','Unidad',NULL,0);
INSERT INTO promocion (titulo,descripcion,fecha_inicio,fecha_fin,activa) VALUES
 ('Semana del cuidado personal','Condiciones por confirmar en tienda. Aplica a productos seleccionados de cuidado personal.','2026-11-16','2026-12-05',1),
 ('Campaña bienestar de verano','Promoción en productos de bienestar seleccionados. Consulte condiciones en la farmacia.','2026-11-01','2026-12-31',1),
 ('Promoción de primavera (finalizada)','Campaña anterior, ya no vigente.','2026-09-01','2026-09-30',1);
INSERT INTO promocion_producto (id_promocion,id_producto) VALUES (1,1),(1,2),(1,3),(2,11),(2,12),(2,5),(3,4);
INSERT INTO servicio (nombre,descripcion,canal_atencion) VALUES
 ('Atención farmacéutica','Orientación sobre los productos disponibles en la farmacia.','Presencial'),
 ('Consultas y pedidos de información','Consultas sobre productos, promociones y horarios.','Formulario web / canales oficiales');
INSERT INTO contenido_salud (titulo,resumen,contenido,fecha_publicacion) VALUES
 ('Lavado de manos: cuándo y cómo','Recomendaciones generales de higiene de manos.','Lavarse las manos con agua y jabón antes de comer, después de usar el baño y al llegar a casa ayuda a reducir la transmisión de gérmenes. Frote durante al menos 20 segundos y seque bien con una toalla limpia. Esta información es general y no reemplaza la orientación de un profesional de la salud.','2026-11-05'),
 ('Hidratación en días de calor','Ideas generales para mantenerse hidratado.','Beber agua a lo largo del día, evitar la exposición prolongada al sol y usar ropa ligera son hábitos generales de cuidado en épocas de calor. Esta información es general y no reemplaza la orientación de un profesional de la salud.','2026-11-10'),
 ('Cómo leer la etiqueta de un producto','Qué datos revisar antes de usar un producto.','Revise siempre la fecha de vencimiento, el modo de uso y las advertencias del envase. Ante dudas sobre un producto, consulte con el personal de la farmacia o con su médico. Esta información es general y no reemplaza la orientación de un profesional de la salud.','2026-11-15');
