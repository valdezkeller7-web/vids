-- Modelo físico MySQL 8 (el mismo del informe, sección 3.6)
CREATE DATABASE IF NOT EXISTS vidsafarma CHARACTER SET utf8mb4;
USE vidsafarma;

CREATE TABLE categoria (
  id_categoria INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE producto (
  id_producto INT AUTO_INCREMENT PRIMARY KEY,
  id_categoria INT NOT NULL,
  nombre VARCHAR(120) NOT NULL,
  descripcion TEXT,
  presentacion VARCHAR(80),
  imagen_url VARCHAR(255),
  destacado BOOLEAN NOT NULL DEFAULT FALSE,
  INDEX idx_producto_categoria (id_categoria),
  INDEX idx_producto_nombre (nombre),
  CONSTRAINT fk_producto_categoria FOREIGN KEY (id_categoria)
    REFERENCES categoria(id_categoria)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE promocion (
  id_promocion INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(120) NOT NULL,
  descripcion TEXT,
  fecha_inicio DATE,
  fecha_fin DATE,
  activa BOOLEAN NOT NULL DEFAULT TRUE,
  CONSTRAINT chk_promocion_fechas CHECK (fecha_fin >= fecha_inicio),
  INDEX idx_promocion_vigencia (activa, fecha_fin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE promocion_producto (
  id_promocion INT NOT NULL,
  id_producto INT NOT NULL,
  PRIMARY KEY (id_promocion, id_producto),
  INDEX idx_pp_producto (id_producto),
  CONSTRAINT fk_pp_promocion FOREIGN KEY (id_promocion)
    REFERENCES promocion(id_promocion)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_pp_producto FOREIGN KEY (id_producto)
    REFERENCES producto(id_producto)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE servicio (
  id_servicio INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  descripcion TEXT,
  canal_atencion VARCHAR(80),
  CONSTRAINT uq_servicio_nombre UNIQUE (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE contenido_salud (
  id_contenido INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(120) NOT NULL,
  resumen VARCHAR(255),
  contenido TEXT NOT NULL,
  fecha_publicacion DATE,
  INDEX idx_contenido_fecha (fecha_publicacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE contacto (
  id_contacto INT AUTO_INCREMENT PRIMARY KEY,
  id_servicio INT NULL,
  nombre VARCHAR(80),
  medio_contacto VARCHAR(50),
  mensaje TEXT NOT NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_contacto_servicio (id_servicio),
  CONSTRAINT fk_contacto_servicio FOREIGN KEY (id_servicio)
    REFERENCES servicio(id_servicio)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
