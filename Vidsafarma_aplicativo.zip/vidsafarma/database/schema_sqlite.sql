-- Esquema de demostración (SQLite). Equivale al modelo físico MySQL 8 de schema_mysql.sql.
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS categoria (
  id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(255)
);
CREATE TABLE IF NOT EXISTS producto (
  id_producto INTEGER PRIMARY KEY AUTOINCREMENT,
  id_categoria INTEGER NOT NULL,
  nombre VARCHAR(120) NOT NULL,
  descripcion TEXT,
  presentacion VARCHAR(80),
  imagen_url VARCHAR(255),
  destacado BOOLEAN NOT NULL DEFAULT 0,
  CONSTRAINT fk_producto_categoria FOREIGN KEY (id_categoria)
    REFERENCES categoria(id_categoria) ON UPDATE CASCADE ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_producto_categoria ON producto(id_categoria);
CREATE INDEX IF NOT EXISTS idx_producto_nombre ON producto(nombre);
CREATE TABLE IF NOT EXISTS promocion (
  id_promocion INTEGER PRIMARY KEY AUTOINCREMENT,
  titulo VARCHAR(120) NOT NULL,
  descripcion TEXT,
  fecha_inicio DATE,
  fecha_fin DATE,
  activa BOOLEAN NOT NULL DEFAULT 1,
  CONSTRAINT chk_promocion_fechas CHECK (fecha_fin >= fecha_inicio)
);
CREATE INDEX IF NOT EXISTS idx_promocion_vigencia ON promocion(activa, fecha_fin);
CREATE TABLE IF NOT EXISTS promocion_producto (
  id_promocion INTEGER NOT NULL,
  id_producto INTEGER NOT NULL,
  PRIMARY KEY (id_promocion, id_producto),
  CONSTRAINT fk_pp_promocion FOREIGN KEY (id_promocion)
    REFERENCES promocion(id_promocion) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_pp_producto FOREIGN KEY (id_producto)
    REFERENCES producto(id_producto) ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_pp_producto ON promocion_producto(id_producto);
CREATE TABLE IF NOT EXISTS servicio (
  id_servicio INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre VARCHAR(80) NOT NULL,
  descripcion TEXT,
  canal_atencion VARCHAR(80),
  CONSTRAINT uq_servicio_nombre UNIQUE (nombre)
);
CREATE TABLE IF NOT EXISTS contenido_salud (
  id_contenido INTEGER PRIMARY KEY AUTOINCREMENT,
  titulo VARCHAR(120) NOT NULL,
  resumen VARCHAR(255),
  contenido TEXT NOT NULL,
  fecha_publicacion DATE
);
CREATE INDEX IF NOT EXISTS idx_contenido_fecha ON contenido_salud(fecha_publicacion);
CREATE TABLE IF NOT EXISTS contacto (
  id_contacto INTEGER PRIMARY KEY AUTOINCREMENT,
  id_servicio INTEGER NULL,
  nombre VARCHAR(80),
  medio_contacto VARCHAR(50),
  mensaje TEXT NOT NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_contacto_servicio FOREIGN KEY (id_servicio)
    REFERENCES servicio(id_servicio) ON UPDATE CASCADE ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_contacto_servicio ON contacto(id_servicio);
