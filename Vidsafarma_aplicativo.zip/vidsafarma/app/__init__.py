"""Composición de capas: Controladores -> Servicios -> DAO -> Base de datos."""
import os
from flask import Flask
from app.config import Config
from app.db import Database
from app.dao import (CategoriaDAO, ProductoDAO, PromocionDAO, ServicioDAO,
                     ContenidoSaludDAO, ContactoDAO)
from app.services import (CatalogoService, PromocionService, InformacionService, ContactoService)
from app.controllers import bp


def create_app(overrides=None, hoy=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if overrides:
        app.config.update(overrides)
    db = Database(app.config)
    cat, prod, promo = CategoriaDAO(db), ProductoDAO(db), PromocionDAO(db)
    app.extensions["db"] = db
    app.extensions["servicios"] = dict(
        catalogo=CatalogoService(cat, prod),
        promociones=PromocionService(promo, prod, hoy),
        informacion=InformacionService(ServicioDAO(db), ContenidoSaludDAO(db)),
        contacto=ContactoService(ContactoDAO(db), app.config["DATOS_CONTACTO"]),
    )
    app.register_blueprint(bp)
    return app


def init_demo_db(app):
    """Crea el esquema y carga datos de demostración si la BD está vacía (SQLite)."""
    base = os.path.join(app.root_path, "..", "database")
    db = app.extensions["db"]
    db.run_script(os.path.join(base, "schema_sqlite.sql"))
    if not db.query("SELECT 1 FROM categoria LIMIT 1"):
        db.run_script(os.path.join(base, "seed.sql"))
