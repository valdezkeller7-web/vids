"""Capa de datos: fábrica de conexiones. Aísla el motor (SQLite o MySQL)."""
import sqlite3


class Database:
    def __init__(self, config):
        self.engine = config["DB_ENGINE"]
        self.config = config

    def _connect(self):
        if self.engine == "mysql":
            import mysql.connector  # se instala solo si se usa MySQL
            return mysql.connector.connect(**self.config["MYSQL"])
        conn = sqlite3.connect(self.config["SQLITE_PATH"])
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _sql(self, sql):
        # Los DAO escriben "?" como marcador; MySQL usa "%s".
        return sql.replace("?", "%s") if self.engine == "mysql" else sql

    def query(self, sql, params=()):
        conn = self._connect()
        try:
            cur = conn.cursor(dictionary=True) if self.engine == "mysql" else conn.cursor()
            cur.execute(self._sql(sql), params)
            rows = cur.fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def execute(self, sql, params=()):
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(self._sql(sql), params)
            conn.commit()
            return cur.lastrowid
        finally:
            conn.close()

    def run_script(self, path):
        """Solo para SQLite (inicialización de la demostración)."""
        conn = self._connect()
        try:
            with open(path, encoding="utf-8") as f:
                conn.executescript(f.read())
            conn.commit()
        finally:
            conn.close()
