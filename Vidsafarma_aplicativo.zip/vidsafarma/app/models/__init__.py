"""MODEL (MVC): entidades del dominio (clases del modelo conceptual)."""
from dataclasses import dataclass
from typing import Optional


@dataclass
class Categoria:
    id_categoria: int
    nombre: str
    descripcion: Optional[str] = None


@dataclass
class Producto:
    id_producto: int
    id_categoria: int
    nombre: str
    descripcion: Optional[str] = None
    presentacion: Optional[str] = None
    imagen_url: Optional[str] = None
    destacado: bool = False


@dataclass
class Promocion:
    id_promocion: int
    titulo: str
    descripcion: Optional[str] = None
    fecha_inicio: Optional[str] = None
    fecha_fin: Optional[str] = None
    activa: bool = True


@dataclass
class Servicio:
    id_servicio: int
    nombre: str
    descripcion: Optional[str] = None
    canal_atencion: Optional[str] = None


@dataclass
class ContenidoSalud:
    id_contenido: int
    titulo: str
    contenido: str
    resumen: Optional[str] = None
    fecha_publicacion: Optional[str] = None


@dataclass
class Contacto:
    nombre: str
    medio_contacto: str
    mensaje: str
    id_servicio: Optional[int] = None
    id_contacto: Optional[int] = None
