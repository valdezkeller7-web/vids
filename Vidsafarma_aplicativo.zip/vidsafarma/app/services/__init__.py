"""Capa de negocio: reglas del sitio publicitario. No conoce HTTP ni SQL."""
import re
from datetime import date
from app.models import Contacto


class CatalogoService:
    def __init__(self, categoria_dao, producto_dao):
        self.categorias, self.productos = categoria_dao, producto_dao

    def listar_categorias(self):
        conteo = self.productos.contar_por_categoria()
        return [(c, conteo.get(c.id_categoria, 0)) for c in self.categorias.listar()]

    def productos_de_categoria(self, id_categoria):
        """CU01/CU02: valida la categoría y devuelve (categoria, productos) o None."""
        cat = self.categorias.obtener(id_categoria)
        if cat is None:
            return None
        return cat, self.productos.listar_por_categoria(id_categoria)

    def detalle_producto(self, id_producto):
        p = self.productos.obtener(id_producto)
        if p is None:
            return None
        return p, self.categorias.obtener(p.id_categoria)

    def destacados(self):
        return self.productos.listar_destacados()


class PromocionService:
    def __init__(self, promocion_dao, producto_dao, hoy=None):
        self.promociones, self.productos = promocion_dao, producto_dao
        self._hoy = hoy

    def hoy(self):
        return (self._hoy or date.today()).isoformat()

    def vigentes(self):
        """CU03: solo promociones activas y dentro de su vigencia (no muestra vencidas)."""
        return [(p, self.productos.listar_por_promocion(p.id_promocion))
                for p in self.promociones.listar_vigentes(self.hoy())]


class InformacionService:
    def __init__(self, servicio_dao, contenido_dao):
        self.servicios, self.contenidos = servicio_dao, contenido_dao

    def servicios_publicados(self): return self.servicios.listar()
    def articulos(self): return self.contenidos.listar()
    def articulo(self, id_contenido): return self.contenidos.obtener(id_contenido)


class ContactoService:
    """CU07 (opcional): valida campos obligatorios y registra la consulta."""
    EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    TELEFONO = re.compile(r"^[0-9+\s()-]{7,20}$")

    def __init__(self, contacto_dao, datos_contacto):
        self.contactos, self.datos = contacto_dao, datos_contacto

    def datos_publicados(self):
        """CU06: solo se publican los datos confirmados por la empresa."""
        return {k: v for k, v in self.datos.items() if v}

    def validar(self, nombre, medio, mensaje):
        errores = {}
        if not (nombre or "").strip(): errores["nombre"] = "Ingrese su nombre."
        medio = (medio or "").strip()
        if not medio: errores["medio_contacto"] = "Ingrese un correo o teléfono de respuesta."
        elif not (self.EMAIL.match(medio) or self.TELEFONO.match(medio)):
            errores["medio_contacto"] = "Ingrese un correo o teléfono válido."
        msg = (mensaje or "").strip()
        if not msg: errores["mensaje"] = "Escriba su consulta."
        elif len(msg) < 10: errores["mensaje"] = "La consulta debe tener al menos 10 caracteres."
        return errores

    def enviar(self, nombre, medio, mensaje, id_servicio=None):
        errores = self.validar(nombre, medio, mensaje)
        if errores:
            return None, errores
        c = Contacto(nombre.strip(), medio.strip(), mensaje.strip(), id_servicio)
        return self.contactos.guardar(c), {}
