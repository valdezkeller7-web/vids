"""Capa de acceso a datos (patrón DAO). Solo aquí se escribe SQL."""
from app.models import Categoria, Producto, Promocion, Servicio, ContenidoSalud, Contacto


def _build(cls, row):
    if row is None:
        return None
    campos = cls.__dataclass_fields__.keys()
    datos = {k: row[k] for k in campos if k in row}
    if "destacado" in datos:
        datos["destacado"] = bool(datos["destacado"])
    if "activa" in datos:
        datos["activa"] = bool(datos["activa"])
    return cls(**datos)


class CategoriaDAO:
    def __init__(self, db): self.db = db

    def listar(self):
        return [_build(Categoria, r) for r in self.db.query(
            "SELECT * FROM categoria ORDER BY nombre")]

    def obtener(self, id_categoria):
        r = self.db.query("SELECT * FROM categoria WHERE id_categoria = ?", (id_categoria,))
        return _build(Categoria, r[0]) if r else None

    def eliminar(self, id_categoria):
        self.db.execute("DELETE FROM categoria WHERE id_categoria = ?", (id_categoria,))


class ProductoDAO:
    def __init__(self, db): self.db = db

    def listar_por_categoria(self, id_categoria):
        return [_build(Producto, r) for r in self.db.query(
            "SELECT * FROM producto WHERE id_categoria = ? ORDER BY nombre", (id_categoria,))]

    def listar_destacados(self, limite=6):
        return [_build(Producto, r) for r in self.db.query(
            "SELECT * FROM producto WHERE destacado = 1 ORDER BY nombre LIMIT ?", (limite,))]

    def obtener(self, id_producto):
        r = self.db.query("SELECT * FROM producto WHERE id_producto = ?", (id_producto,))
        return _build(Producto, r[0]) if r else None

    def contar_por_categoria(self):
        rows = self.db.query("SELECT id_categoria, COUNT(*) AS total FROM producto GROUP BY id_categoria")
        return {r["id_categoria"]: r["total"] for r in rows}

    def listar_por_promocion(self, id_promocion):
        return [_build(Producto, r) for r in self.db.query(
            "SELECT p.* FROM producto p JOIN promocion_producto pp ON pp.id_producto = p.id_producto "
            "WHERE pp.id_promocion = ? ORDER BY p.nombre", (id_promocion,))]


class PromocionDAO:
    def __init__(self, db): self.db = db

    def listar_vigentes(self, hoy):
        return [_build(Promocion, r) for r in self.db.query(
            "SELECT * FROM promocion WHERE activa = 1 AND (fecha_inicio IS NULL OR fecha_inicio <= ?) "
            "AND (fecha_fin IS NULL OR fecha_fin >= ?) ORDER BY fecha_fin", (hoy, hoy))]

    def crear(self, titulo, descripcion, fecha_inicio, fecha_fin, activa=True):
        return self.db.execute(
            "INSERT INTO promocion (titulo, descripcion, fecha_inicio, fecha_fin, activa) VALUES (?,?,?,?,?)",
            (titulo, descripcion, fecha_inicio, fecha_fin, 1 if activa else 0))


class ServicioDAO:
    def __init__(self, db): self.db = db

    def listar(self):
        return [_build(Servicio, r) for r in self.db.query("SELECT * FROM servicio ORDER BY nombre")]

    def eliminar(self, id_servicio):
        self.db.execute("DELETE FROM servicio WHERE id_servicio = ?", (id_servicio,))


class ContenidoSaludDAO:
    def __init__(self, db): self.db = db

    def listar(self):
        return [_build(ContenidoSalud, r) for r in self.db.query(
            "SELECT * FROM contenido_salud ORDER BY fecha_publicacion DESC")]

    def obtener(self, id_contenido):
        r = self.db.query("SELECT * FROM contenido_salud WHERE id_contenido = ?", (id_contenido,))
        return _build(ContenidoSalud, r[0]) if r else None


class ContactoDAO:
    def __init__(self, db): self.db = db

    def guardar(self, c: Contacto):
        return self.db.execute(
            "INSERT INTO contacto (id_servicio, nombre, medio_contacto, mensaje) VALUES (?,?,?,?)",
            (c.id_servicio, c.nombre, c.medio_contacto, c.mensaje))

    def contar(self):
        return self.db.query("SELECT COUNT(*) AS n FROM contacto")[0]["n"]

    def obtener(self, id_contacto):
        r = self.db.query("SELECT * FROM contacto WHERE id_contacto = ?", (id_contacto,))
        return r[0] if r else None
