"""Configuración del aplicativo (capa transversal)."""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Config:
    # "sqlite" para la demostración local; "mysql" para el modelo físico MySQL 8.
    DB_ENGINE = os.getenv("VIDSAFARMA_DB_ENGINE", "sqlite")
    SQLITE_PATH = os.getenv("VIDSAFARMA_SQLITE", os.path.join(BASE_DIR, "vidsafarma.db"))
    MYSQL = dict(
        host=os.getenv("MYSQL_HOST", "localhost"),
        port=int(os.getenv("MYSQL_PORT", "3306")),
        user=os.getenv("MYSQL_USER", "vidsafarma"),
        password=os.getenv("MYSQL_PASSWORD", ""),
        database=os.getenv("MYSQL_DB", "vidsafarma"),
    )
    SECRET_KEY = os.getenv("SECRET_KEY", "cambiar-en-produccion")
    # Datos pendientes de validación por la empresa (CU06, flujo alternativo 2a):
    # los valores en None no se publican.
    DATOS_CONTACTO = dict(direccion=None, horario=None, telefono=None, correo=None)
