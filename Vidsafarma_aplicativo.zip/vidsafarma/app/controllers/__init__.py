"""CONTROLLER (MVC): recibe la petición HTTP, invoca al servicio y elige la vista."""
from flask import Blueprint, render_template, abort, request, redirect, url_for, flash, current_app

bp = Blueprint("web", __name__)


def svc(nombre):
    return current_app.extensions["servicios"][nombre]


@bp.route("/")
def inicio():
    return render_template("inicio.html", destacados=svc("catalogo").destacados(),
                           promos=svc("promociones").vigentes()[:2],
                           categorias=svc("catalogo").listar_categorias())


@bp.route("/categorias")
def categorias():
    return render_template("categorias.html", categorias=svc("catalogo").listar_categorias())


@bp.route("/categorias/<int:id_categoria>")
def categoria(id_categoria):
    r = svc("catalogo").productos_de_categoria(id_categoria)
    if r is None:
        abort(404)
    return render_template("categoria.html", categoria=r[0], productos=r[1])


@bp.route("/productos/<int:id_producto>")
def producto(id_producto):
    r = svc("catalogo").detalle_producto(id_producto)
    if r is None:
        abort(404)
    return render_template("producto.html", producto=r[0], categoria=r[1])


@bp.route("/promociones")
def promociones():
    return render_template("promociones.html", promos=svc("promociones").vigentes())


@bp.route("/servicios")
def servicios():
    return render_template("servicios.html", servicios=svc("informacion").servicios_publicados())


@bp.route("/salud")
def salud():
    return render_template("salud.html", articulos=svc("informacion").articulos())


@bp.route("/salud/<int:id_contenido>")
def articulo(id_contenido):
    a = svc("informacion").articulo(id_contenido)
    if a is None:
        abort(404)
    return render_template("articulo.html", a=a)


@bp.route("/contacto", methods=["GET", "POST"])
def contacto():
    cs = svc("contacto")
    servicios = svc("informacion").servicios_publicados()
    if request.method == "POST":
        f = request.form
        id_serv = f.get("id_servicio", type=int)
        ok, errores = cs.enviar(f.get("nombre"), f.get("medio_contacto"), f.get("mensaje"), id_serv)
        if errores:
            return render_template("contacto.html", datos=cs.datos_publicados(), servicios=servicios,
                                   errores=errores, valores=f), 400
        flash("¡Gracias! Recibimos su consulta y la responderemos por el medio indicado.")
        return redirect(url_for("web.contacto"))
    return render_template("contacto.html", datos=cs.datos_publicados(), servicios=servicios,
                           errores={}, valores={})


@bp.app_errorhandler(404)
def no_encontrado(_):
    return render_template("404.html"), 404
