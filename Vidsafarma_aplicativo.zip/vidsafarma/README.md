# Vidsafarma – Sitio web publicitario e informativo (APF3)

Aplicativo en Python 3 + Flask con patrones **MVC + DAO + Capas** conectado a una base de datos relacional.
Los datos cargados son **de demostración**; deben reemplazarse por el catálogo validado por la empresa.

## Estructura
- `app/models`      Modelo (entidades del dominio)
- `app/dao`         Capa de acceso a datos (único lugar con SQL)
- `app/services`    Capa de negocio (reglas: vigencia de promociones, validación del formulario)
- `app/controllers` Controladores (rutas HTTP)
- `app/templates`, `app/static` Vistas y estilos
- `database/`       `schema_mysql.sql` (modelo físico MySQL 8), `schema_sqlite.sql`, `seed.sql`
- `tests/`          23 pruebas automatizadas (unittest)

## Ejecutar (demostración con SQLite)
    pip install -r requirements.txt
    python run.py            # http://127.0.0.1:5000

## Usar MySQL 8
    pip install mysql-connector-python
    mysql -u root -p < database/schema_mysql.sql
    set VIDSAFARMA_DB_ENGINE=mysql   (Linux/macOS: export ...)
    set MYSQL_USER=... MYSQL_PASSWORD=... MYSQL_DB=vidsafarma
    python run.py
(Cargue los datos con `database/seed.sql` si desea el contenido de ejemplo.)

## Pruebas
    python -m unittest discover -v
