from app import create_app, init_demo_db

app = create_app()
if app.config["DB_ENGINE"] == "sqlite":
    init_demo_db(app)

if __name__ == "__main__":
    app.run(debug=False, port=5000)
